RegisterCommand("backflip", function()
    local playerPed = PlayerPedId()
    local dict = "mp_suicide"
    local anim = "pistol"

    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Citizen.Wait(100)
    end

    TaskPlayAnim(playerPed, dict, anim, 8.0, -8.0, 2000, 0, 0, false, false, false)
end, false)

RegisterKeyMapping("backflip", "Fazer um Mortal para Trás", "keyboard", "U")
--------------- By BispoNoobDev----------------------