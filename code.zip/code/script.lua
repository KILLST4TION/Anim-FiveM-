local isCrouching = false
local dict = "move_ped_crouched"

Citizen.CreateThread(function()
    RequestAnimSet(dict)
    while not HasAnimSetLoaded(dict) do
        Citizen.Wait(100)
    end

    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, 73) then -- Tecla X
            local playerPed = PlayerPedId()
            if not isCrouching then
                SetPedMovementClipset(playerPed, dict, 0.25)
                SetPedUsingActionMode(playerPed, true, -1, 0) -- Garante que pode usar arma
                isCrouching = true
            else
                ResetPedMovementClipset(playerPed, 0.25)
                SetPedUsingActionMode(playerPed, false, -1, 0) -- Sai do modo de ação
                isCrouching = false
            end
        end
    end
end)
---------------By BispoNoobDev----------------------